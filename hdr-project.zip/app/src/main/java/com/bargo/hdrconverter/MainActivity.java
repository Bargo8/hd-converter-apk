package com.bargo.hdrconverter;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(), "AndroidInterface");
        webView.loadUrl("file:///android_asset/index.html");
    }
    public class WebAppInterface {
        @JavascriptInterface
        public void runFFmpeg() {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Mulai proses...", Toast.LENGTH_SHORT).show());
            String inputFile = "/storage/emulated/0/Download/video.mp4"; 
            String outputFile = "/storage/emulated/0/Download/video_HDR.mp4";
            String command = "-y -i " + inputFile + " -vf scale=1920:1080:flags=lanczos,curves=preset=lighter,format=yuv420p10le -c:v libx265 -preset ultrafast -crf 22 -x265-params hdr-opt=1:repeat-headers=1:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc -c:a copy " + outputFile;
            FFmpegKit.executeAsync(command, session -> {
                ReturnCode returnCode = session.getReturnCode();
                if (ReturnCode.isSuccess(returnCode)) {
                    webView.post(() -> webView.evaluateJavascript("updateLog('Selesai!')", null));
                } else {
                    webView.post(() -> webView.evaluateJavascript("updateLog('Gagal!')", null));
                }
            }, log -> {
                String message = log.getMessage();
                webView.post(() -> webView.evaluateJavascript("updateLog('" + message.replace("'", "\\'").replace("\n", " ") + "')", null));
            }, statistics -> {});
        }
    }
}
